package com.app.dtos;

public enum CartStatusDTO {
    ACTIVE,
    INACTIVE
}
