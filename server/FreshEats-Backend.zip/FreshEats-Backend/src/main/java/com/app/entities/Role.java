package com.app.entities;

public enum Role {
	SELLER, USER
}
