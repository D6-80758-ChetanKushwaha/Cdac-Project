package com.app.dtos;

public class CartDTO {

}
