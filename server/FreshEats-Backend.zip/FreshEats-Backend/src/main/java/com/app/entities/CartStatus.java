package com.app.entities;

public enum CartStatus {
	ACTIVE,
	INACTIVE
}
