package com.app.entities;

public enum OrderStatus {
	COMPLETED, PENDING, CANCELLED
}
