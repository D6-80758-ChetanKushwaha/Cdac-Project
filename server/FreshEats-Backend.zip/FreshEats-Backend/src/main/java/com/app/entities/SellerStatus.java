package com.app.entities;

public enum SellerStatus {
	ACTIVE, INACTIVE, DELETED
}
