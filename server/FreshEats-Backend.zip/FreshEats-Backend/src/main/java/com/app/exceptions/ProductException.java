package com.app.exceptions;

public class ProductException extends Exception {

}
